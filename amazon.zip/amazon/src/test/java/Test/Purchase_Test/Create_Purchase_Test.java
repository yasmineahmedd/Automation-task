package Test.Purchase_Test;


import org.json.simple.parser.ParseException;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pages.dashboard.Home_Page;
import pages.dashboard.Login;
import procedure.customer_purchase.Customer_Purchase;
import utilities.Actions;
import utilities.chrome_Initialization;

import java.io.IOException;

import static org.testng.AssertJUnit.assertEquals;


public class Create_Purchase_Test {
    WebDriver driver;
    Login login ;
    chrome_Initialization chromeIntialization = new chrome_Initialization();
    Actions actions;
    Home_Page homePage;
    Customer_Purchase createPurchase;


    @BeforeTest
    public void setup(){
        driver = chromeIntialization.setup();
        login = new Login(driver);
        homePage= new Home_Page(driver);
        createPurchase= new Customer_Purchase(driver);
        login.loginTest();
    }


    @Test
    public void createAPurchase() throws InterruptedException, IOException, ParseException {
       createPurchase.buyProduct();


    }










}
