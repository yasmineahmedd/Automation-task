package utilities;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.*;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class Actions {
    WebDriver driver=null;
    WebDriverWait wait;


    public Actions(WebDriver driver) {

        this.driver=driver;
        Duration duration = Duration.ofSeconds(20);
        wait = new WebDriverWait(driver, duration);
    }

    public void clickElement(By xpath){
        wait.until(ExpectedConditions.elementToBeClickable(xpath));
        driver.findElement(xpath).click();

    }

    public void switchWindow()
    {
        String mainWindowHandle = driver.getWindowHandle();
        Set<String> allWindowHandles = driver.getWindowHandles();
        Iterator<String> iterator = allWindowHandles.iterator();

        while (iterator.hasNext())
        {
            String ChildWindow = iterator.next();
            if (!mainWindowHandle.equalsIgnoreCase(ChildWindow))
            {
                driver.switchTo().window(ChildWindow);
            }
        }
    }
    public void sendElement(By xpath,String data){
        //wait(xpath);
        wait.until(ExpectedConditions.elementToBeClickable(xpath));
        driver.findElement(xpath).sendKeys(data);

    }

    public void selectDropDown (By element, String text) {
        Select title = new Select (driver.findElement(element));
        title.selectByVisibleText(text);
    }

    public void switchingFrames(int index){
        driver.switchTo().defaultContent();
        driver.switchTo().frame(index);
    }

}
