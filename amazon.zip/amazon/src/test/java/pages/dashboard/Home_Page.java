package pages.dashboard;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import utilities.Actions;
import static org.testng.AssertJUnit.assertEquals;
import static org.testng.AssertJUnit.assertTrue;

public class Home_Page {
    WebDriver driver= null;
    Actions actions;
    public Home_Page(WebDriver driver){
        this.driver= driver;
        actions= new Actions(driver);

    }

    By allButton=By.xpath("//*[@id=\"nav-hamburger-menu\"]");
    By seeAllBtn=By.xpath("//div[text()='See all']");

    //By women=By.xpath("//*[@class=\"hmenu-item\"] [@data-menu-id=\"6\"]");
    By videoGames=By.xpath("//*[@class=\"hmenu-item\"] [@data-menu-id=\"16\"]");
    By allVideoGames=By.xpath("//*[text()='All Video Games']");
    By freeShipping=By.xpath("//*[@class=\"a-size-base a-color-base\"] [text()='Free Shipping']");
    By newFilter=By.xpath("//*[text()='New']");
    By sortBy=By.xpath("//*[@aria-label=\"Sort by:\"]");
    By fromHighToLow=By.xpath("//*[@id=\"s-result-sort-select_2\"]");
    By maxPrice= By.xpath("//*[@placeholder=\"Max\"]");
    By goBtn= By.xpath("//*[@class=\"a-button a-spacing-top-mini a-button-base s-small-margin-left\"]");
    By selectedProduct=By.xpath("//*[@src=\"https://m.media-amazon.com/images/I/61HMKtNZr7L._AC_UY218_.jpg\"]");
    By seeAllBuyingOptions=By.xpath("//*[@title=\"See All Buying Options\"]");
    By addToCart=By.xpath("//*[@name=\"submit.addToCart\"]");
    By addedText=By.xpath("//*[text()='Added']");
    By viewCartBtn=By.xpath("//*[@aria-labelledby=\"aod-offer-view-cart-1-announce\"]");
    By proceedToBuy=By.xpath("//*[@value=\"Proceed to checkout\"]");
    By orderWithoutPrime=By.xpath("//*[@id=\"prime-declineCTA\"]");
    By cashOnDelivery=By.xpath("//*[@value=\"instrumentId=0h_PE_CUS_18b1c868-2e63-40e2-8b24-414fe05d88c8%2FCash&isExpired=false&paymentMethod=COD&tfxEligible=false\"]");
    By usePaymentMethod=By.xpath("//*[@name=\"ppw-widgetEvent:SetPaymentPlanSelectContinueEvent\"]");


    public void clickAll() throws InterruptedException {

        actions.clickElement(allButton);
        //wait(5000);
    }
//    public  void clickWomen(){
//        actions.clickElement(women);
//    }
    public void clickSeeAll() {
        actions.clickElement(seeAllBtn);
    }
    public void clickVideoGames(){

        actions.clickElement(videoGames);

    }
    public void clickAllVideoGames(){

        actions.clickElement(allVideoGames);
    }

    public void clickFreeShipping(){
        actions.clickElement(freeShipping);
    }

    public void clickNewFilter(){
        actions.clickElement(newFilter);
    }

    public void sortFromHighToLow(){
        actions.clickElement(sortBy);
        actions.clickElement(fromHighToLow);
    }

    public void enterMaxPrice(){
        actions.sendElement(maxPrice,"15000");
        actions.clickElement(goBtn);
    }

    public void selectProduct(){
        actions.clickElement(selectedProduct);
    }

    public void addToCart(){
        actions.clickElement(seeAllBuyingOptions);
        actions.clickElement(addToCart);
        actions.clickElement(viewCartBtn);
    }

    public void proceedToBuy(){
        actions.clickElement(proceedToBuy);
        actions.clickElement(orderWithoutPrime);
        actions.clickElement(cashOnDelivery);
        actions.clickElement(usePaymentMethod);
    }




}
