package procedure.customer_purchase;


import org.json.simple.parser.ParseException;
import org.openqa.selenium.WebDriver;
import pages.dashboard.Home_Page;
import utilities.Actions;

import java.io.IOException;

public class Customer_Purchase {
WebDriver driver;
Home_Page homePage;
Actions actions;
//Create_Individual_page createIndividualPage;

//un_Authorized_Customer unAuthorizedCustomer;
public Customer_Purchase(WebDriver driver){
    this.driver= driver;
    homePage= new Home_Page(driver);
    //createIndividualPage= new Create_Individual_page(driver);
    //unAuthorizedCustomer = new un_Authorized_Customer(driver);
}



public void buyProduct() throws IOException, ParseException, InterruptedException {



    homePage.clickAll();
    //homePage.clickWomen();
    homePage.clickSeeAll();
    homePage.clickVideoGames();
    homePage.clickAllVideoGames();
    homePage.clickFreeShipping();
    homePage.clickNewFilter();
    homePage.sortFromHighToLow();
    homePage.enterMaxPrice();
    homePage.selectProduct();
    homePage.addToCart();
    homePage.proceedToBuy();


}






}
