package utilities;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;



public class chrome_Initialization {

    WebDriver driver;
//   public chrome_Initialization(WebDriver driver) {
//       this.driver= driver;
//   }
    public WebDriver setup(){

        ChromeOptions chromeOptions = new ChromeOptions();
        WebDriverManager.chromedriver().setup();
        //options.add_argument('--ignore-ssl-errors=yes')
        chromeOptions.addArguments("--ignore-certificate-errors");
        driver = new ChromeDriver(chromeOptions);
        driver.get("https://www.amazon.eg/");
        driver.manage().window().maximize();
        return driver;

    }
}
