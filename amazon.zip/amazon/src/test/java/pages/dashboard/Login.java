package pages.dashboard;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import utilities.Actions;

import static org.testng.AssertJUnit.assertEquals;

public class Login {

    WebDriver driver= null;
    Actions actions ;

    By signInButton=By.xpath("//*[@id=\"nav-link-accountList\"]");

    By userNameTextField= By.xpath("//*[@name=\"email\"]");
    By userNameContinueButton= By.xpath("//*[@aria-labelledby=\"continue-announce\"]");
    By passwordTextField= By.xpath("//*[@id=\"ap_password\"]");
    By signBtn= By.xpath("//*[@id=\"signInSubmit\"]");
    By ss= By.xpath("[id=\"signOnName\"]");
    public Login(WebDriver driver) {
        this.driver= driver;
        actions= new Actions(driver);
    }

    public void clickToSignIn(){
        actions.clickElement(signInButton);
    }

    public void enterUsername(String username) {

        actions.sendElement(userNameTextField,username);
    }
    public void clickContinue(){
        actions.clickElement(userNameContinueButton);
    }
    public void enterPassword(String password) {
        actions.sendElement(passwordTextField,password);

    }
    public void clickSignIn() {

        actions.clickElement(signBtn);
    }

   public void loginTest(){
       String username="yasmine.ahmed2910@gmail.com";
       String password="qwerty123456";
       //String Text="Sign Off";
       clickToSignIn();
       enterUsername(username);
       clickContinue();
       enterPassword(password);
       clickSignIn();
       //driver.switchTo().frame(0);
       //assertEquals(Text, driver.findElement(By.xpath("//a[@alt='Sign off']")).getText());
   }
}
